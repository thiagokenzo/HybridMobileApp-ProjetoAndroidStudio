package com.example.checkpoint01

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_calc.*


class CalcActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calc)


        btnCalcCalc.setOnClickListener {
            if (camposValidos() and rbSoma.isChecked) {
                val Calc1 = txtCalc1.text.toString().toDouble()
                val Calc2 = txtCalc2.text.toString().toDouble()
                val soma = soma(Calc1, Calc2)
                Toast.makeText(this, soma.toString(), Toast.LENGTH_LONG).show()
            }
            else if (camposValidos() and rbSubtracao.isChecked) {
                val Calc1 = txtCalc1.text.toString().toDouble()
                val Calc2 = txtCalc2.text.toString().toDouble()
                val subtracao = subtracao(Calc1, Calc2)
                Toast.makeText(this, subtracao.toString(), Toast.LENGTH_LONG).show()
            }
            else if (camposValidos() and rbMultiplicacao.isChecked) {
                val Calc1 = txtCalc1.text.toString().toDouble()
                val Calc2 = txtCalc2.text.toString().toDouble()
                val multiplicacao = multiplicacao(Calc1, Calc2)
                Toast.makeText(this, multiplicacao.toString(), Toast.LENGTH_LONG).show()
            }
            else if (camposValidos() and rbDivisao.isChecked) {
                val Calc1 = txtCalc1.text.toString().toDouble()
                val Calc2 = txtCalc2.text.toString().toDouble()
                val divisao = divisao(Calc1, Calc2)
                Toast.makeText(this, divisao.toString(), Toast.LENGTH_LONG).show()
            }
        }
    }

    fun camposValidos() : Boolean{
        var msg = ""
        if(txtCalc1.text.trim().isEmpty()){
            msg = "Informe o Valor 1"
        }
        else if(txtCalc2.text.trim().isEmpty()) {
            msg = "Informe o Valor 2"
        }
        else{
            return true
        }
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
        return false
    }

    fun soma(Calc1: Double, Calc2: Double) : Double{
        return Calc1 + Calc2
    }

    fun subtracao(Calc1: Double, Calc2: Double) : Double{
        return Calc1 - Calc2
    }

    fun multiplicacao(Calc1: Double, Calc2: Double) : Double{
        return Calc1 * Calc2
    }

    fun divisao(Calc1: Double, Calc2: Double) : Double{
        return Calc1/Calc2
    }
}