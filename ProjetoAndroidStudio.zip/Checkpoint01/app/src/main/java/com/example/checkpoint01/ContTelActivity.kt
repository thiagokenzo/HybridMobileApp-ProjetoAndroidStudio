package com.example.checkpoint01

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_cont_tel.*

class ContTelActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cont_tel)

        btnCalc.setOnClickListener{
            if(camposValidos()){
                var n1 = txtN1.text.toString().toDouble()
                var n2 = txtN2.text.toString().toDouble()
                var n3 = txtN3.text.toString().toDouble()
                val soma = soma(n1, n2, n3)
                val intentResultado = Intent(this, ResultadoActivity::class.java)
                intentResultado.putExtra("n1", n1)
                intentResultado.putExtra("n2", n2 * 0.04)
                intentResultado.putExtra("n3", n3 * 0.2)
                intentResultado.putExtra("resultado", soma)
                startActivity(intentResultado)
            }
        }
    }

    fun camposValidos() : Boolean{
        var msg = ""
        if(txtN1.text.trim().isEmpty()){
            msg = "Informe o valor da assinatura."
        }
        else if(txtN2.text.trim().isEmpty()) {
            msg = "Informe a quantidade de minutos de chamada local."
        }
        else if(txtN3.text.trim().isEmpty()) {
            msg = "Informe a quantidade de minutos de chamada para celular."
        }
        else{
            return true
        }
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
        return false
    }

    fun soma(n1: Double, n2: Double, n3: Double) : Double{
        return n1 + (n2 * 0.04) + (n3 * 0.2)
    }
}