package com.example.checkpoint01

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_resultado.*

class ResultadoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_resultado)

        val n1 = String.format("%.2f", intent.getDoubleExtra("n1", 0.0))
        val n2 = String.format("%.2f", intent.getDoubleExtra("n2", 0.0))
        val n3 = String.format("%.2f", intent.getDoubleExtra("n3", 0.0))
        val soma = String.format("%.2f", intent.getDoubleExtra("resultado", 0.0))
        val msg = "Assinatura: R$$n1 \nChamada Local: R$$n2 \nChamada Celular: R$$n3 \n\nValor Total: R$$soma"
        tvResultado.text = msg

    }
}